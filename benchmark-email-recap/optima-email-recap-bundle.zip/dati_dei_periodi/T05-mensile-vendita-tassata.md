Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Luglio 2026.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Luglio 2026 ===

--- PATRIMONIO ---
Inizio periodo: 296.500 €
Fine periodo: 300.370 €
Variazione assoluta: 3870 €
Variazione %: +1.31%

--- CASHFLOW ---
Entrate (esclusi dividendi): 6100 €
Dividendi e cedole: 0 €
Uscite: -2345 €
Flusso netto: 3755 €
Numero transazioni: 34 (di cui 32 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 6100 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 1880 € (31%)
Desideri: 465 € (8%)
Risparmi: 3755 € (61%): 0 € di spese classificate come risparmio + 3755 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -780 € (1 transazione, 33,3% delle uscite)
  › Rata: -780 € (1 transazione)
Alimentari: -540 € (9 transazioni, 23,0% delle uscite)
  › Supermercato: -470 € (7 transazioni)
  › Mercato: -70 € (2 transazioni)
Casa: -290 € (3 transazioni, 12,4% delle uscite)
  › Bollette: -205 € (2 transazioni)
  › Condominio: -85 € (1 transazione)
Ristoranti: -240 € (5 transazioni, 10,2% delle uscite)
Trasporti: -210 € (5 transazioni, 9,0% delle uscite)
  › Carburante: -140 € (3 transazioni)
  › Abbonamento treno: -70 € (1 transazione)
Shopping: -170 € (3 transazioni, 7,2% delle uscite)
Salute: -60 € (2 transazioni, 2,6% delle uscite)
Abbonamenti: -55 € (4 transazioni, 2,3% delle uscite)
  › Streaming: -30 € (2 transazioni)
  › Palestra: -25 € (1 transazione)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 3200 € (1 transazione)
Quattordicesima: 2900 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2026-07-02 · Mutuo › Rata: -780 €
2026-07-19 · Alimentari › Supermercato: -141 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Luglio 2026 (1 mese).
• La vendita di VWCE serve ad accantonare la liquidità per un obiettivo di acquisto auto nel 2027.

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +3755 €
Mercato: +1425 €
Tasse sulle vendite: −1310 €
Crescita del patrimonio: +3870 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+0,6% nel mese. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 115.240 € (38,4% del patrimonio)
Immobili: 96.000 € (32,0% del patrimonio)
Liquidità: 40.480 € (13,5% del patrimonio)
Obbligazioni: 39.090 € (13,0% del patrimonio)
Materie Prime: 9560 € (3,2% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 204.370 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 56,4% | target 60,0% | scarto −3,6 p.p. (−7382 €) | in linea
Obbligazioni: attuale 19,1% | target 25,0% | scarto −5,9 p.p. (−12.003 €) | fuori target
Materie Prime: attuale 4,7% | target 5,0% | scarto −0,3 p.p. (−659 €) | in linea
Liquidità: attuale 19,8% | target 10,0% | scarto +9,8 p.p. (+20.043 €) | fuori target
Fuori dal totale 96.000 € esclusi (1 asset): il patrimonio è 300.370 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione −15.760 € = mercato +1240 € + acquisti e vendite −17.000 €
Obbligazioni: variazione +90 € = mercato +90 €
Materie Prime: variazione +60 € = mercato +60 €
Liquidità: variazione +19.480 € = mercato +35 € + altri movimenti +19.445 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 1 acquisto per 7,6 quote, 1000 € investiti (commissioni incluse); 1 vendita per 132 quote, 18.000 € incassati al netto delle commissioni (tassa stimata 1310 €)
Totale del periodo: 1000 € investiti in 1 acquisto; 18.000 € incassati da 1 vendita. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 0 € lordi in 0 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Giugno 2026) ---
Patrimonio netto: +3870 € (+1,3%), da 296.500 € a 300.370 €
Entrate: +2660 € (+77,3%), da 3440 € a 6100 €
Uscite: +63 € (+2,8%), da 2282 € a 2345 €
Risparmio netto: +2597 € (+224,3%), da +1158 € a +3755 €

--- CONFRONTO CON LO STESSO PERIODO DELL'ANNO PRECEDENTE (Luglio 2025) ---
Patrimonio netto: +45.370 € (+17,8%), da 255.000 € a 300.370 €
Entrate: +300 € (+5,2%), da 5800 € a 6100 €
Uscite: +110 € (+4,9%), da 2235 € a 2345 €
Risparmio netto: +190 € (+5,3%), da +3565 € a +3755 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 780 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 540 € (vs periodo prec.: +22 € (+4,2%); vs anno prec.: +38 € (+7,6%))
- Casa: 290 € (vs periodo prec.: +12 € (+4,3%); vs anno prec.: +20 € (+7,4%))
- Ristoranti: 240 € (vs periodo prec.: +10 € (+4,3%); vs anno prec.: +17 € (+7,6%))
- Trasporti: 210 € (vs periodo prec.: +8 € (+4,0%); vs anno prec.: +15 € (+7,7%))
- Shopping: 170 € (vs periodo prec.: +7 € (+4,3%); vs anno prec.: +12 € (+7,6%))
- Salute: 60 € (vs periodo prec.: +2 € (+3,4%); vs anno prec.: +4 € (+7,1%))
- Abbonamenti: 55 € (vs periodo prec.: +2 € (+3,8%); vs anno prec.: +4 € (+7,8%))

--- HALL OF FAME ---
È il 12° mese per crescita tra i 32 mesi in crescita registrati.
In altre parole: a metà classifica tra le crescite.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

--- CONTESTO MACRO (newsletter TheBull, luglio 2026) ---
Per ogni mese: i fatti per area, le tesi dell'autore e i rendimenti degli indici a fine mese.

## Macro di luglio 2026

### Fatti

#### Tassi

- Il rendimento del Bund decennale risale al 2,7%. — _Eurozona_ (2026-W29)

#### Banche centrali

- La BCE taglia di 25 punti base, ma la conferenza stampa raffredda le attese su ulteriori tagli. — _Eurozona_ (2026-W30)

#### Crescita

- Il mercato del lavoro statunitense rallenta: 90.000 nuovi occupati, sotto le attese. — _Stati Uniti_ (2026-W30)

#### Azionario

- Forte rotazione settoriale: tecnologia in calo, energia e finanziari in rialzo. — _Stati Uniti_ (2026-W28)

#### Obbligazionario

- Le obbligazioni a lunga scadenza perdono terreno sul rialzo dei rendimenti. — _Globale_ (2026-W28)

#### Materie prime

- L'oro corregge del 4% dopo il massimo di inizio mese. — _Globale_ (2026-W29)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore vede rischi sulla duration lunga finché l'inflazione dei servizi resta alta. (2026-W30)
- **Azionario** — Per l'autore la rotazione settoriale premia chi è diversificato a livello globale. (2026-W30)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | -0.90% | +7.20% |
| FTSE MIB | +1.20% | +10.50% |
| Bloomberg Euro Aggregate | -1.10% | +3.40% |
| Oro | -4.00% | +21.00% |

_Variazioni in % in Euro._

