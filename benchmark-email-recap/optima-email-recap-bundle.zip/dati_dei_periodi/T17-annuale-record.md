Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Anno 2025.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Anno 2025 ===

--- PATRIMONIO ---
Inizio periodo: 238.200 €
Fine periodo: 282.265 €
Variazione assoluta: 44.065 €
Variazione %: +18.50%

--- CASHFLOW ---
Entrate (esclusi dividendi): 43.650 €
Dividendi e cedole: 0 €
Uscite: -32.440 €
Flusso netto: 11.210 €
Numero transazioni: 409 (di cui 395 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 43.650 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 22.560 € (52%)
Desideri: 9880 € (23%)
Risparmi: 11.210 € (25%): 0 € di spese classificate come risparmio + 11.210 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -9360 € (12 transazioni, 28,9% delle uscite)
  › Rata: -9360 € (12 transazioni)
Alimentari: -6480 € (108 transazioni, 20,0% delle uscite)
  › Supermercato: -5640 € (84 transazioni)
  › Mercato: -840 € (24 transazioni)
Viaggi: -4300 € (11 transazioni, 13,3% delle uscite)
Casa: -3480 € (36 transazioni, 10,7% delle uscite)
  › Bollette: -2460 € (24 transazioni)
  › Condominio: -1020 € (12 transazioni)
Ristoranti: -2880 € (60 transazioni, 8,9% delle uscite)
Trasporti: -2520 € (60 transazioni, 7,8% delle uscite)
  › Carburante: -1680 € (36 transazioni)
  › Abbonamento treno: -840 € (12 transazioni)
Shopping: -2040 € (36 transazioni, 6,3% delle uscite)
Salute: -720 € (24 transazioni, 2,2% delle uscite)
Abbonamenti: -660 € (48 transazioni, 2,0% delle uscite)
  › Streaming: -360 € (24 transazioni)
  › Palestra: -300 € (12 transazioni)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 36.600 € (12 transazioni)
Tredicesima: 2850 € (1 transazione)
Bonus: 4200 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2025-08-06 · Viaggi – Giappone: -1900 €
2025-02-14 · Shopping – telefono: -650 €
2025-11-03 · Casa › Bollette: -260 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Elenco completo (2). Il "valore attuale" è la quota di portafoglio assegnata all'obiettivo, non un conto separato.
Indipendenza finanziaria: valore attuale 152.000 € | target 1.100.000 € (13,8% raggiunto) | scadenza 2039-12-31 | priorità high | contributo mensile pianificato 1000 €
  › stato: in linea con la scadenza al ritmo attuale
  › versamento mensile necessario per arrivare al target entro la scadenza: 940 € (proiezione, ipotizzando un rendimento nominale del 5,6% annuo)
  › valore proiettato alla scadenza al ritmo attuale: 1.160.000 €
Auto nuova: valore attuale 9500 € | target 18.000 € (52,8% raggiunto) | scadenza 2027-06-30 | priorità high | contributo mensile pianificato 400 €
  › stato: in ritardo: al ritmo attuale non arriva al target entro la scadenza
  › versamento mensile necessario per arrivare al target entro la scadenza: 470 € (proiezione, ipotizzando un rendimento nominale del 2,1% annuo)
  › valore proiettato alla scadenza al ritmo attuale: 16.900 €

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]
Viaggi [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Anno 2025 (12 mesi).

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +11.210 €
Mercato: +20.730 €
Mutuo rimborsato: +5800 €
Versamenti al fondo pensione: +5600 €
Altre variazioni: +725 €
Crescita del patrimonio: +44.065 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+11,8% annualizzato. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 116.600 € (41,3% del patrimonio)
Immobili: 95.300 € (33,8% del patrimonio)
Obbligazioni: 42.400 € (15,0% del patrimonio)
Liquidità: 17.815 € (6,3% del patrimonio)
Materie Prime: 10.150 € (3,6% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 186.965 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 62,4% | target 60,0% | scarto +2,4 p.p. (+4421 €) | in linea
Obbligazioni: attuale 22,7% | target 25,0% | scarto −2,3 p.p. (−4341 €) | in linea
Materie Prime: attuale 5,4% | target 5,0% | scarto +0,4 p.p. (+802 €) | in linea
Liquidità: attuale 9,5% | target 10,0% | scarto −0,5 p.p. (−882 €) | in linea
Fuori dal totale 95.300 € esclusi (1 asset): il patrimonio è 282.265 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +27.600 € = mercato +15.600 € + acquisti e vendite +12.000 €
Obbligazioni: variazione +2650 € = mercato +650 € + acquisti e vendite +2000 €
Materie Prime: variazione +2950 € = mercato +2950 €
Liquidità: variazione −1685 € = mercato +380 € + altri movimenti −2065 €
Previdenza: variazione +6750 € = mercato +1150 € + versamenti al fondo pensione +5600 €
Immobili: variazione +5800 € = mercato 0 € + altri movimenti +5800 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 12 acquisti per 103,5 quote, 12.000 € investiti (commissioni incluse)
- AGGH (Obbligazioni › Aggregate globale): 1 acquisto per 420 quote, 2000 € investiti (commissioni incluse)
Totale del periodo: 14.000 € investiti in 13 acquisti. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 725 € lordi in 3 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Anno 2024) ---
Patrimonio netto: +44.065 € (+18,5%), da 238.200 € a 282.265 €
Entrate: +4950 € (+12,8%), da 38.700 € a 43.650 €
Uscite: +2840 € (+9,6%), da 29.600 € a 32.440 €
Risparmio netto: +2110 € (+23,2%), da +9100 € a +11.210 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 9360 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 6480 € (vs periodo prec.: +259 € (+4,2%); vs anno prec.: +454 € (+7,5%))
- Viaggi: 4300 € (vs periodo prec.: +700 € (+19,4%); vs anno prec.: +700 € (+19,4%))
- Casa: 3480 € (vs periodo prec.: +139 € (+4,2%); vs anno prec.: +244 € (+7,5%))
- Ristoranti: 2880 € (vs periodo prec.: +115 € (+4,2%); vs anno prec.: +202 € (+7,5%))
- Trasporti: 2520 € (vs periodo prec.: +101 € (+4,2%); vs anno prec.: +176 € (+7,5%))
- Shopping: 2040 € (vs periodo prec.: +82 € (+4,2%); vs anno prec.: +143 € (+7,5%))
- Salute: 720 € (vs periodo prec.: +29 € (+4,2%); vs anno prec.: +50 € (+7,5%))
- Abbonamenti: 660 € (vs periodo prec.: +26 € (+4,1%); vs anno prec.: +46 € (+7,5%))

--- HALL OF FAME ---
È il anno con la crescita più alta tra i 5 anni in crescita registrati.
In altre parole: tra le crescite più forti.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

--- CONTESTO MACRO (newsletter TheBull, gennaio 2025, febbraio 2025, marzo 2025, aprile 2025, maggio 2025, giugno 2025, luglio 2025, agosto 2025, settembre 2025, ottobre 2025, novembre 2025, dicembre 2025) ---
Per ogni mese: i 2 fatti più recenti per area, le 8 tesi più recenti dell'autore e i rendimenti degli indici a fine mese.

## Macro di gennaio 2025

### Fatti

#### Banche centrali

- La Fed mantiene i tassi invariati e rinvia ogni taglio alle prossime riunioni. — _Stati Uniti_ (2025-W04)

#### Inflazione

- L'inflazione core statunitense resta al 3,0%. — _Stati Uniti_ (2025-W06)

#### Crescita

- Il PIL italiano cresce dello 0,1% trimestre su trimestre. — _Italia_ (2025-W05)

#### Azionario

- L'Euro Stoxx 50 chiude il mese quasi invariato dopo oscillazioni ampie. — _Europa_ (2025-W05)

#### Debito pubblico

- Un'agenzia di rating conferma il giudizio sull'Italia con outlook stabile. — _Italia_ (2025-W04)

#### Materie prime

- Il petrolio Brent oscilla tra 65 e 70 dollari al barile. — _Globale_ (2025-W06)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore considera probabile una lunga fase laterale dei tassi. (2025-W06)
- **Azionario** — Secondo l'autore la diversificazione in oro ha fatto il suo lavoro negli ultimi due anni. (2025-W06)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +0.40% | +9.80% |
| FTSE MIB | +0.90% | +12.10% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di febbraio 2025

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2025-W08)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2025-W10)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2025-W08)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2025-W09)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2025-W09)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2025-W08)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2025-W10)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2025-W10)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2025-W10)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di marzo 2025

### Fatti

#### Tassi

- Il rendimento del Treasury decennale scende al 3,9% per la fuga verso i titoli rifugio. — _Stati Uniti_ (2025-W14)

#### Crescita

- Il PMI manifatturiero tedesco torna sotto 50. — _Eurozona_ (2025-W13)

#### Azionario

- L'MSCI World perde oltre il 6% nel mese in euro, con vendite concentrate sui titoli tecnologici. — _Globale_ (2025-W12)

#### Obbligazionario

- Lo spread BTP-Bund si allarga a 135 punti base. — _Italia_ (2025-W14)

#### Cambio

- Il dollaro si indebolisce contro euro e franco svizzero. — _Globale_ (2025-W12)

#### Materie prime

- L'oro sale sopra i 3.300 dollari l'oncia. — _Globale_ (2025-W12)

#### Politica

- Nuovi dazi annunciati sulle importazioni europee aumentano la volatilità. — _Stati Uniti_ (2025-W13)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Per l'autore la correzione è una reazione alla politica commerciale più che un cambio del ciclo economico. (2025-W14)
- **Azionario** — L'autore invita a non vendere in preda al panico e a usare la liquidità solo secondo il piano. (2025-W14)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | -6.35% | +2.10% |
| FTSE MIB | -7.10% | +4.60% |
| Bloomberg Euro Aggregate | +0.80% | +3.40% |
| Oro | +4.20% | +21.00% |

_Variazioni in % in Euro._

## Macro di aprile 2025

### Fatti

#### Tassi

- Il rendimento del Treasury decennale scende al 3,9% per la fuga verso i titoli rifugio. — _Stati Uniti_ (2025-W18)

#### Crescita

- Il PMI manifatturiero tedesco torna sotto 50. — _Eurozona_ (2025-W17)

#### Azionario

- L'MSCI World perde oltre il 6% nel mese in euro, con vendite concentrate sui titoli tecnologici. — _Globale_ (2025-W16)

#### Obbligazionario

- Lo spread BTP-Bund si allarga a 135 punti base. — _Italia_ (2025-W18)

#### Cambio

- Il dollaro si indebolisce contro euro e franco svizzero. — _Globale_ (2025-W16)

#### Materie prime

- L'oro sale sopra i 3.300 dollari l'oncia. — _Globale_ (2025-W16)

#### Politica

- Nuovi dazi annunciati sulle importazioni europee aumentano la volatilità. — _Stati Uniti_ (2025-W17)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Per l'autore la correzione è una reazione alla politica commerciale più che un cambio del ciclo economico. (2025-W18)
- **Azionario** — L'autore invita a non vendere in preda al panico e a usare la liquidità solo secondo il piano. (2025-W18)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | -6.35% | +2.10% |
| FTSE MIB | -7.10% | +4.60% |
| Bloomberg Euro Aggregate | +0.80% | +3.40% |
| Oro | +4.20% | +21.00% |

_Variazioni in % in Euro._

## Macro di maggio 2025

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2025-W20)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2025-W22)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2025-W20)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2025-W21)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2025-W21)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2025-W20)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2025-W22)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2025-W22)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2025-W22)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di giugno 2025

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2025-W24)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2025-W26)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2025-W24)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2025-W25)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2025-W25)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2025-W24)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2025-W26)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2025-W26)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2025-W26)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di luglio 2025

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2025-W28)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2025-W30)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2025-W28)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2025-W29)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2025-W29)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2025-W28)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2025-W30)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2025-W30)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2025-W30)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di agosto 2025

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2025-W32)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2025-W34)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2025-W32)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2025-W33)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2025-W33)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2025-W32)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2025-W34)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2025-W34)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2025-W34)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di settembre 2025

### Fatti

#### Tassi

- Il rendimento del Bund decennale risale al 2,7%. — _Eurozona_ (2025-W37)

#### Banche centrali

- La BCE taglia di 25 punti base, ma la conferenza stampa raffredda le attese su ulteriori tagli. — _Eurozona_ (2025-W38)

#### Crescita

- Il mercato del lavoro statunitense rallenta: 90.000 nuovi occupati, sotto le attese. — _Stati Uniti_ (2025-W38)

#### Azionario

- Forte rotazione settoriale: tecnologia in calo, energia e finanziari in rialzo. — _Stati Uniti_ (2025-W36)

#### Obbligazionario

- Le obbligazioni a lunga scadenza perdono terreno sul rialzo dei rendimenti. — _Globale_ (2025-W36)

#### Materie prime

- L'oro corregge del 4% dopo il massimo di inizio mese. — _Globale_ (2025-W37)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore vede rischi sulla duration lunga finché l'inflazione dei servizi resta alta. (2025-W38)
- **Azionario** — Per l'autore la rotazione settoriale premia chi è diversificato a livello globale. (2025-W38)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | -0.90% | +7.20% |
| FTSE MIB | +1.20% | +10.50% |
| Bloomberg Euro Aggregate | -1.10% | +3.40% |
| Oro | -4.00% | +21.00% |

_Variazioni in % in Euro._

## Macro di ottobre 2025

### Fatti

#### Banche centrali

- La Fed mantiene i tassi invariati e rinvia ogni taglio alle prossime riunioni. — _Stati Uniti_ (2025-W40)

#### Inflazione

- L'inflazione core statunitense resta al 3,0%. — _Stati Uniti_ (2025-W42)

#### Crescita

- Il PIL italiano cresce dello 0,1% trimestre su trimestre. — _Italia_ (2025-W41)

#### Azionario

- L'Euro Stoxx 50 chiude il mese quasi invariato dopo oscillazioni ampie. — _Europa_ (2025-W41)

#### Debito pubblico

- Un'agenzia di rating conferma il giudizio sull'Italia con outlook stabile. — _Italia_ (2025-W40)

#### Materie prime

- Il petrolio Brent oscilla tra 65 e 70 dollari al barile. — _Globale_ (2025-W42)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore considera probabile una lunga fase laterale dei tassi. (2025-W42)
- **Azionario** — Secondo l'autore la diversificazione in oro ha fatto il suo lavoro negli ultimi due anni. (2025-W42)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +0.40% | +9.80% |
| FTSE MIB | +0.90% | +12.10% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di novembre 2025

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2025-W44)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2025-W46)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2025-W44)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2025-W45)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2025-W45)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2025-W44)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2025-W46)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2025-W46)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2025-W46)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di dicembre 2025

### Fatti

#### Banche centrali

- La Fed mantiene i tassi invariati e rinvia ogni taglio alle prossime riunioni. — _Stati Uniti_ (2025-W48)

#### Inflazione

- L'inflazione core statunitense resta al 3,0%. — _Stati Uniti_ (2025-W50)

#### Crescita

- Il PIL italiano cresce dello 0,1% trimestre su trimestre. — _Italia_ (2025-W49)

#### Azionario

- L'Euro Stoxx 50 chiude il mese quasi invariato dopo oscillazioni ampie. — _Europa_ (2025-W49)

#### Debito pubblico

- Un'agenzia di rating conferma il giudizio sull'Italia con outlook stabile. — _Italia_ (2025-W48)

#### Materie prime

- Il petrolio Brent oscilla tra 65 e 70 dollari al barile. — _Globale_ (2025-W50)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore considera probabile una lunga fase laterale dei tassi. (2025-W50)
- **Azionario** — Secondo l'autore la diversificazione in oro ha fatto il suo lavoro negli ultimi due anni. (2025-W50)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +0.40% | +9.80% |
| FTSE MIB | +0.90% | +12.10% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

