Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Anno 2023.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Anno 2023 ===

--- PATRIMONIO ---
Inizio periodo: 202.940 €
Fine periodo: 228.650 €
Variazione assoluta: 25.710 €
Variazione %: +12.67%

--- CASHFLOW ---
Entrate (esclusi dividendi): 36.200 €
Dividendi e cedole: 0 €
Uscite: -28.140 €
Flusso netto: 8060 €
Numero transazioni: 397 (di cui 384 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 36.200 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 22.560 € (62%)
Desideri: 5580 € (15%)
Risparmi: 8060 € (23%): 0 € di spese classificate come risparmio + 8060 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -9360 € (12 transazioni, 33,3% delle uscite)
  › Rata: -9360 € (12 transazioni)
Alimentari: -6480 € (108 transazioni, 23,0% delle uscite)
  › Supermercato: -5640 € (84 transazioni)
  › Mercato: -840 € (24 transazioni)
Casa: -3480 € (36 transazioni, 12,4% delle uscite)
  › Bollette: -2460 € (24 transazioni)
  › Condominio: -1020 € (12 transazioni)
Ristoranti: -2880 € (60 transazioni, 10,2% delle uscite)
Trasporti: -2520 € (60 transazioni, 9,0% delle uscite)
  › Carburante: -1680 € (36 transazioni)
  › Abbonamento treno: -840 € (12 transazioni)
Shopping: -2040 € (36 transazioni, 7,2% delle uscite)
Salute: -720 € (24 transazioni, 2,6% delle uscite)
Abbonamenti: -660 € (48 transazioni, 2,3% delle uscite)
  › Streaming: -360 € (24 transazioni)
  › Palestra: -300 € (12 transazioni)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 33.600 € (12 transazioni)
Tredicesima: 2600 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2023-07-20 · Viaggi – Grecia: -1200 €
2023-03-02 · Mutuo › Rata: -780 €
2023-10-15 · Salute – dentista: -320 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Elenco completo (2). Il "valore attuale" è la quota di portafoglio assegnata all'obiettivo, non un conto separato.
Indipendenza finanziaria: valore attuale 128.000 € | target 1.100.000 € (11,6% raggiunto) | scadenza 2039-12-31 | priorità high | contributo mensile pianificato 600 €
  › stato: in ritardo: al ritmo attuale non arriva al target entro la scadenza
  › versamento mensile necessario per arrivare al target entro la scadenza: 1150 € (proiezione, ipotizzando un rendimento nominale del 5,4% annuo)
  › valore proiettato alla scadenza al ritmo attuale: 870.000 €
Fondo emergenza: valore attuale 15.000 € | target 15.000 € (100,0% raggiunto) | nessuna scadenza | priorità high
  › stato: raggiunto

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Anno 2023 (12 mesi).
• Nel 2023 molti acquisti piccoli e sparsi su ETF diversi: il PAC unico su VWCE parte dal 2024.

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +8060 €
Mercato: +11.130 €
Mutuo rimborsato: +5450 €
Altre variazioni: +1070 €
Crescita del patrimonio: +25.710 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+9,2% annualizzato. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Immobili: 91.750 € (40,1% del patrimonio)
Azioni: 80.600 € (35,3% del patrimonio)
Obbligazioni: 28.800 € (12,6% del patrimonio)
Liquidità: 21.540 € (9,4% del patrimonio)
Materie Prime: 5960 € (2,6% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 136.900 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 58,9% | target 60,0% | scarto −1,1 p.p. (−1540 €) | in linea
Obbligazioni: attuale 21,0% | target 25,0% | scarto −4,0 p.p. (−5425 €) | in linea
Materie Prime: attuale 4,4% | target 5,0% | scarto −0,6 p.p. (−885 €) | in linea
Liquidità: attuale 15,7% | target 10,0% | scarto +5,7 p.p. (+7850 €) | fuori target
Fuori dal totale 91.750 € esclusi (1 asset): il patrimonio è 228.650 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +14.300 € = mercato +9100 € + acquisti e vendite +5200 €
Obbligazioni: variazione +3800 € = mercato +1100 € + acquisti e vendite +2700 €
Materie Prime: variazione +1620 € = mercato +520 € + acquisti e vendite +1100 €
Liquidità: variazione +540 € = mercato +410 € + altri movimenti +130 €
Immobili: variazione +5450 € = mercato 0 € + altri movimenti +5450 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VNGA60 (Azioni › Globale 60% · Obbligazioni › Aggregate globale 40%): 4 acquisti per 75 quote, 2500 € investiti (commissioni incluse)
- BTP 2033 (Obbligazioni › Governativi Italia): 2 acquisti per 1700 quote, 1700 € investiti (commissioni incluse)
- SGLD (Materie Prime › Oro): 1 acquisto per 6 quote, 1100 € investiti (commissioni incluse)
- IWDA (Azioni): 1 acquisto per 3 quote, 400 € investiti (commissioni incluse)
- EIMI (Azioni): 1 acquisto per 4 quote, 400 € investiti (commissioni incluse)
- ZPRV (Azioni): 1 acquisto per 5 quote, 400 € investiti (commissioni incluse)
- ZPRX (Azioni): 1 acquisto per 6 quote, 400 € investiti (commissioni incluse)
- XDEM (Azioni): 1 acquisto per 7 quote, 120 € investiti (commissioni incluse)
- IUSN (Azioni): 1 acquisto per 8 quote, 120 € investiti (commissioni incluse)
- CSPX (Azioni): 1 acquisto per 9 quote, 120 € investiti (commissioni incluse)
- MEUD (Azioni): 1 acquisto per 10 quote, 120 € investiti (commissioni incluse)
- SWDA (Azioni): 1 acquisto per 11 quote, 120 € investiti (commissioni incluse)
- IS3N (Azioni): 1 acquisto per 12 quote, 120 € investiti (commissioni incluse)
- VFEM (Azioni): 1 acquisto per 13 quote, 120 € investiti (commissioni incluse)
- CNDX (Azioni): 1 acquisto per 14 quote, 120 € investiti (commissioni incluse)
Oltre i primi 15 restano 4 strumenti per 480 € di operazioni complessive.
Totale del periodo: 8340 € investiti in 23 acquisti. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 410 € lordi in 4 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Anno 2022) ---
Patrimonio netto: +25.710 € (+12,7%), da 202.940 € a 228.650 €
Entrate: +1950 € (+5,7%), da 34.250 € a 36.200 €
Uscite: +440 € (+1,6%), da 27.700 € a 28.140 €
Risparmio netto: +1510 € (+23,1%), da +6550 € a +8060 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 9360 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 6480 € (vs periodo prec.: +259 € (+4,2%); vs anno prec.: +454 € (+7,5%))
- Casa: 3480 € (vs periodo prec.: +139 € (+4,2%); vs anno prec.: +244 € (+7,5%))
- Ristoranti: 2880 € (vs periodo prec.: +115 € (+4,2%); vs anno prec.: +202 € (+7,5%))
- Trasporti: 2520 € (vs periodo prec.: +101 € (+4,2%); vs anno prec.: +176 € (+7,5%))
- Shopping: 2040 € (vs periodo prec.: +82 € (+4,2%); vs anno prec.: +143 € (+7,5%))
- Salute: 720 € (vs periodo prec.: +29 € (+4,2%); vs anno prec.: +50 € (+7,5%))
- Abbonamenti: 660 € (vs periodo prec.: +26 € (+4,1%); vs anno prec.: +46 € (+7,5%))

--- HALL OF FAME ---
È il anno con la crescita più piccola tra i 3 anni in crescita registrati.
In altre parole: tra le crescite più deboli.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

