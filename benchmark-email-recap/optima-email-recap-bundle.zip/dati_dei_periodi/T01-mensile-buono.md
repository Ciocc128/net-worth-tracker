Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Maggio 2026.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Maggio 2026 ===

--- PATRIMONIO ---
Inizio periodo: 283.500 €
Fine periodo: 287.780 €
Variazione assoluta: 4280 €
Variazione %: +1.51%

--- CASHFLOW ---
Entrate (esclusi dividendi): 3200 €
Dividendi e cedole: 0 €
Uscite: -2345 €
Flusso netto: 855 €
Numero transazioni: 33 (di cui 32 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 3200 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 1880 € (59%)
Desideri: 465 € (15%)
Risparmi: 855 € (26%): 0 € di spese classificate come risparmio + 855 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -780 € (1 transazione, 33,3% delle uscite)
  › Rata: -780 € (1 transazione)
Alimentari: -540 € (9 transazioni, 23,0% delle uscite)
  › Supermercato: -470 € (7 transazioni)
  › Mercato: -70 € (2 transazioni)
Casa: -290 € (3 transazioni, 12,4% delle uscite)
  › Bollette: -205 € (2 transazioni)
  › Condominio: -85 € (1 transazione)
Ristoranti: -240 € (5 transazioni, 10,2% delle uscite)
Trasporti: -210 € (5 transazioni, 9,0% delle uscite)
  › Carburante: -140 € (3 transazioni)
  › Abbonamento treno: -70 € (1 transazione)
Shopping: -170 € (3 transazioni, 7,2% delle uscite)
Salute: -60 € (2 transazioni, 2,6% delle uscite)
Abbonamenti: -55 € (4 transazioni, 2,3% delle uscite)
  › Streaming: -30 € (2 transazioni)
  › Palestra: -25 € (1 transazione)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 3200 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2026-05-02 · Mutuo › Rata: -780 €
2026-05-18 · Alimentari › Supermercato: -132 €
2026-05-24 · Ristoranti – cena compleanno: -96 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Maggio 2026 (1 mese).

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +855 €
Mercato: +3425 €
Crescita del patrimonio: +4280 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+1,9% nel mese. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 116.350 € (40,4% del patrimonio)
Immobili: 96.000 € (33,4% del patrimonio)
Obbligazioni: 39.120 € (13,6% del patrimonio)
Liquidità: 26.900 € (9,3% del patrimonio)
Materie Prime: 9410 € (3,3% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 191.780 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 60,7% | target 60,0% | scarto +0,7 p.p. (+1282 €) | in linea
Obbligazioni: attuale 20,4% | target 25,0% | scarto −4,6 p.p. (−8825 €) | in linea
Materie Prime: attuale 4,9% | target 5,0% | scarto −0,1 p.p. (−179 €) | in linea
Liquidità: attuale 14,0% | target 10,0% | scarto +4,0 p.p. (+7722 €) | fuori target
Fuori dal totale 96.000 € esclusi (1 asset): il patrimonio è 287.780 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +4350 € = mercato +3350 € + acquisti e vendite +1000 €
Obbligazioni: variazione +120 € = mercato +120 €
Materie Prime: variazione −90 € = mercato −90 €
Liquidità: variazione −100 € = mercato +45 € + altri movimenti −145 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 1 acquisto per 8,1 quote, 1000 € investiti (commissioni incluse)
Totale del periodo: 1000 € investiti in 1 acquisto. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 0 € lordi in 0 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Aprile 2026) ---
Patrimonio netto: +4280 € (+1,5%), da 283.500 € a 287.780 €
Entrate: +0 € (+0,0%), da 3200 € a 3200 €
Uscite: +63 € (+2,8%), da 2282 € a 2345 €
Risparmio netto: −63 € (−6,9%), da +918 € a +855 €

--- CONFRONTO CON LO STESSO PERIODO DELL'ANNO PRECEDENTE (Maggio 2025) ---
Patrimonio netto: +39.780 € (+16,0%), da 248.000 € a 287.780 €
Entrate: +150 € (+4,9%), da 3050 € a 3200 €
Uscite: +110 € (+4,9%), da 2235 € a 2345 €
Risparmio netto: +40 € (+4,9%), da +815 € a +855 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 780 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 540 € (vs periodo prec.: +22 € (+4,2%); vs anno prec.: +38 € (+7,6%))
- Casa: 290 € (vs periodo prec.: +12 € (+4,3%); vs anno prec.: +20 € (+7,4%))
- Ristoranti: 240 € (vs periodo prec.: +10 € (+4,3%); vs anno prec.: +17 € (+7,6%))
- Trasporti: 210 € (vs periodo prec.: +8 € (+4,0%); vs anno prec.: +15 € (+7,7%))
- Shopping: 170 € (vs periodo prec.: +7 € (+4,3%); vs anno prec.: +12 € (+7,6%))
- Salute: 60 € (vs periodo prec.: +2 € (+3,4%); vs anno prec.: +4 € (+7,1%))
- Abbonamenti: 55 € (vs periodo prec.: +2 € (+3,8%); vs anno prec.: +4 € (+7,8%))

--- HALL OF FAME ---
È il 5° mese per crescita tra i 31 mesi in crescita registrati.
In altre parole: tra le crescite più forti.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

--- CONTESTO MACRO (newsletter TheBull, maggio 2026) ---
Per ogni mese: i fatti per area, le tesi dell'autore e i rendimenti degli indici a fine mese.

## Macro di maggio 2026

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2026-W20)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2026-W22)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2026-W20)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2026-W21)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2026-W21)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2026-W20)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2026-W22)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2026-W22)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2026-W22)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

