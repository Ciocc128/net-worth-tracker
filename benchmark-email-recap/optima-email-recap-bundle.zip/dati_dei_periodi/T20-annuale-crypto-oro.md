Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Anno 2024.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Anno 2024 ===

--- PATRIMONIO ---
Inizio periodo: 209.900 €
Fine periodo: 243.000 €
Variazione assoluta: 33.100 €
Variazione %: +15.77%

--- CASHFLOW ---
Entrate (esclusi dividendi): 38.700 €
Dividendi e cedole: 0 €
Uscite: -28.140 €
Flusso netto: 10.560 €
Numero transazioni: 399 (di cui 384 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 38.700 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 22.560 € (58%)
Desideri: 5580 € (14%)
Risparmi: 10.560 € (28%): 0 € di spese classificate come risparmio + 10.560 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -9360 € (12 transazioni, 33,3% delle uscite)
  › Rata: -9360 € (12 transazioni)
Alimentari: -6480 € (108 transazioni, 23,0% delle uscite)
  › Supermercato: -5640 € (84 transazioni)
  › Mercato: -840 € (24 transazioni)
Casa: -3480 € (36 transazioni, 12,4% delle uscite)
  › Bollette: -2460 € (24 transazioni)
  › Condominio: -1020 € (12 transazioni)
Ristoranti: -2880 € (60 transazioni, 10,2% delle uscite)
Trasporti: -2520 € (60 transazioni, 9,0% delle uscite)
  › Carburante: -1680 € (36 transazioni)
  › Abbonamento treno: -840 € (12 transazioni)
Shopping: -2040 € (36 transazioni, 7,2% delle uscite)
Salute: -720 € (24 transazioni, 2,6% delle uscite)
Abbonamenti: -660 € (48 transazioni, 2,3% delle uscite)
  › Streaming: -360 € (24 transazioni)
  › Palestra: -300 € (12 transazioni)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 34.800 € (12 transazioni)
Tredicesima: 2700 € (1 transazione)
Vendita usato: 1200 € (2 transazioni)

--- SPESE SINGOLE PIU' GRANDI ---
2024-08-12 · Viaggi – Portogallo: -1450 €
2024-04-02 · Mutuo › Rata: -780 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Anno 2024 (12 mesi).

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +10.560 €
Mercato: +16.420 €
Mutuo rimborsato: +5600 €
Altre variazioni: +520 €
Crescita del patrimonio: +33.100 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+12,4% annualizzato. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 89.800 € (37,0% del patrimonio)
Immobili: 89.600 € (36,9% del patrimonio)
Obbligazioni: 27.300 € (11,2% del patrimonio)
Liquidità: 23.600 € (9,7% del patrimonio)
Criptovalute: 7300 € (3,0% del patrimonio)
Materie Prime: 5400 € (2,2% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 153.400 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 58,5% | target 60,0% | scarto −1,5 p.p. (−2240 €) | in linea
Obbligazioni: attuale 17,8% | target 25,0% | scarto −7,2 p.p. (−11.050 €) | fuori target
Materie Prime: attuale 3,5% | target 5,0% | scarto −1,5 p.p. (−2270 €) | fuori target
Liquidità: attuale 15,4% | target 10,0% | scarto +5,4 p.p. (+8260 €) | fuori target
Criptovalute: attuale 4,8% | target 0,0% | scarto +4,8 p.p. (+7300 €) | in linea
Fuori dal totale 89.600 € esclusi (1 asset): il patrimonio è 243.000 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +17.800 € = mercato +10.800 € + acquisti e vendite +7000 €
Obbligazioni: variazione +1300 € = mercato +300 € + acquisti e vendite +1000 €
Materie Prime: variazione +1100 € = mercato +1100 €
Liquidità: variazione +3100 € = mercato +520 € + altri movimenti +2580 €
Criptovalute: variazione +4200 € = mercato +3700 € + acquisti e vendite +500 €
Immobili: variazione +5600 € = mercato 0 € + altri movimenti +5600 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 7 acquisti per 66 quote, 7000 € investiti (commissioni incluse)
- AGGH (Obbligazioni › Aggregate globale): 1 acquisto per 220 quote, 1000 € investiti (commissioni incluse)
- BTC (Criptovalute): 2 acquisti per 0,009 quote, 500 € investiti (commissioni incluse)
Totale del periodo: 8500 € investiti in 10 acquisti. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 520 € lordi in 3 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Anno 2023) ---
Patrimonio netto: +33.100 € (+15,8%), da 209.900 € a 243.000 €
Entrate: +2500 € (+6,9%), da 36.200 € a 38.700 €
Uscite: +240 € (+0,9%), da 27.900 € a 28.140 €
Risparmio netto: +2260 € (+27,2%), da +8300 € a +10.560 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 9360 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 6480 € (vs periodo prec.: +259 € (+4,2%); vs anno prec.: +454 € (+7,5%))
- Casa: 3480 € (vs periodo prec.: +139 € (+4,2%); vs anno prec.: +244 € (+7,5%))
- Ristoranti: 2880 € (vs periodo prec.: +115 € (+4,2%); vs anno prec.: +202 € (+7,5%))
- Trasporti: 2520 € (vs periodo prec.: +101 € (+4,2%); vs anno prec.: +176 € (+7,5%))
- Shopping: 2040 € (vs periodo prec.: +82 € (+4,2%); vs anno prec.: +143 € (+7,5%))
- Salute: 720 € (vs periodo prec.: +29 € (+4,2%); vs anno prec.: +50 € (+7,5%))
- Abbonamenti: 660 € (vs periodo prec.: +26 € (+4,1%); vs anno prec.: +46 € (+7,5%))

--- HALL OF FAME ---
È il 2° anno per crescita tra i 4 anni in crescita registrati.
In altre parole: a metà classifica tra le crescite.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

