Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Marzo 2026.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Marzo 2026 ===

--- PATRIMONIO ---
Inizio periodo: 290.000 €
Fine periodo: 284.025 €
Variazione assoluta: -5975 €
Variazione %: -2.06%

--- CASHFLOW ---
Entrate (esclusi dividendi): 3200 €
Dividendi e cedole: 0 €
Uscite: -2295 €
Flusso netto: 905 €
Numero transazioni: 33 (di cui 32 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 3200 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 1880 € (59%)
Desideri: 415 € (13%)
Risparmi: 905 € (28%): 0 € di spese classificate come risparmio + 905 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -780 € (1 transazione, 34,0% delle uscite)
  › Rata: -780 € (1 transazione)
Alimentari: -540 € (9 transazioni, 23,5% delle uscite)
  › Supermercato: -470 € (7 transazioni)
  › Mercato: -70 € (2 transazioni)
Casa: -290 € (3 transazioni, 12,6% delle uscite)
  › Bollette: -205 € (2 transazioni)
  › Condominio: -85 € (1 transazione)
Trasporti: -210 € (5 transazioni, 9,2% delle uscite)
  › Carburante: -140 € (3 transazioni)
  › Abbonamento treno: -70 € (1 transazione)
Ristoranti: -190 € (5 transazioni, 8,3% delle uscite)
Shopping: -170 € (3 transazioni, 7,4% delle uscite)
Salute: -60 € (2 transazioni, 2,6% delle uscite)
Abbonamenti: -55 € (4 transazioni, 2,4% delle uscite)
  › Streaming: -30 € (2 transazioni)
  › Palestra: -25 € (1 transazione)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 3200 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2026-03-02 · Mutuo › Rata: -780 €
2026-03-11 · Alimentari › Supermercato: -118 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Marzo 2026 (1 mese).

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +905 €
Mercato: −6880 €
Crescita del patrimonio: −5975 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
−4,3% nel mese. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 111.850 € (39,4% del patrimonio)
Immobili: 96.000 € (33,8% del patrimonio)
Obbligazioni: 39.310 € (13,8% del patrimonio)
Liquidità: 26.945 € (9,5% del patrimonio)
Materie Prime: 9920 € (3,5% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 188.025 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 59,5% | target 60,0% | scarto −0,5 p.p. (−965 €) | in linea
Obbligazioni: attuale 20,9% | target 25,0% | scarto −4,1 p.p. (−7696 €) | in linea
Materie Prime: attuale 5,3% | target 5,0% | scarto +0,3 p.p. (+519 €) | in linea
Liquidità: attuale 14,3% | target 10,0% | scarto +4,3 p.p. (+8143 €) | fuori target
Fuori dal totale 96.000 € esclusi (1 asset): il patrimonio è 284.025 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione −6650 € = mercato −7650 € + acquisti e vendite +1000 €
Obbligazioni: variazione +310 € = mercato +310 €
Materie Prime: variazione +420 € = mercato +420 €
Liquidità: variazione −55 € = mercato +40 € + altri movimenti −95 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 1 acquisto per 8,9 quote, 1000 € investiti (commissioni incluse)
Totale del periodo: 1000 € investiti in 1 acquisto. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 0 € lordi in 0 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Febbraio 2026) ---
Patrimonio netto: −5975 € (−2,1%), da 290.000 € a 284.025 €
Entrate: +0 € (+0,0%), da 3200 € a 3200 €
Uscite: −7 € (−0,3%), da 2302 € a 2295 €
Risparmio netto: +7 € (+0,8%), da +898 € a +905 €

--- CONFRONTO CON LO STESSO PERIODO DELL'ANNO PRECEDENTE (Marzo 2025) ---
Patrimonio netto: +43.025 € (+17,9%), da 241.000 € a 284.025 €
Entrate: +150 € (+4,9%), da 3050 € a 3200 €
Uscite: +53 € (+2,4%), da 2242 € a 2295 €
Risparmio netto: +97 € (+12,0%), da +808 € a +905 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 780 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 540 € (vs periodo prec.: +22 € (+4,2%); vs anno prec.: +38 € (+7,6%))
- Casa: 290 € (vs periodo prec.: +12 € (+4,3%); vs anno prec.: +20 € (+7,4%))
- Trasporti: 210 € (vs periodo prec.: +8 € (+4,0%); vs anno prec.: +15 € (+7,7%))
- Ristoranti: 190 € (vs periodo prec.: −60 € (−24,0%); vs anno prec.: −40 € (−17,4%))
- Shopping: 170 € (vs periodo prec.: +7 € (+4,3%); vs anno prec.: +12 € (+7,6%))
- Salute: 60 € (vs periodo prec.: +2 € (+3,4%); vs anno prec.: +4 € (+7,1%))
- Abbonamenti: 55 € (vs periodo prec.: +2 € (+3,8%); vs anno prec.: +4 € (+7,8%))

--- HALL OF FAME ---
È il 2° mese per ampiezza del calo tra i 9 mesi in calo registrati.
In altre parole: tra i cali più marcati.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

--- CONTESTO MACRO (newsletter TheBull, marzo 2026) ---
Per ogni mese: i fatti per area, le tesi dell'autore e i rendimenti degli indici a fine mese.

## Macro di marzo 2026

### Fatti

#### Tassi

- Il rendimento del Treasury decennale scende al 3,9% per la fuga verso i titoli rifugio. — _Stati Uniti_ (2026-W14)

#### Crescita

- Il PMI manifatturiero tedesco torna sotto 50. — _Eurozona_ (2026-W13)

#### Azionario

- L'MSCI World perde oltre il 6% nel mese in euro, con vendite concentrate sui titoli tecnologici. — _Globale_ (2026-W12)

#### Obbligazionario

- Lo spread BTP-Bund si allarga a 135 punti base. — _Italia_ (2026-W14)

#### Cambio

- Il dollaro si indebolisce contro euro e franco svizzero. — _Globale_ (2026-W12)

#### Materie prime

- L'oro sale sopra i 3.300 dollari l'oncia. — _Globale_ (2026-W12)

#### Politica

- Nuovi dazi annunciati sulle importazioni europee aumentano la volatilità. — _Stati Uniti_ (2026-W13)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Per l'autore la correzione è una reazione alla politica commerciale più che un cambio del ciclo economico. (2026-W14)
- **Azionario** — L'autore invita a non vendere in preda al panico e a usare la liquidità solo secondo il piano. (2026-W14)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | -6.35% | +2.10% |
| FTSE MIB | -7.10% | +4.60% |
| Bloomberg Euro Aggregate | +0.80% | +3.40% |
| Oro | +4.20% | +21.00% |

_Variazioni in % in Euro._

