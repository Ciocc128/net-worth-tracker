Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Anno 2022.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Anno 2022 ===

--- PATRIMONIO ---
Inizio periodo: 196.600 €
Fine periodo: 194.460 €
Variazione assoluta: -2140 €
Variazione %: -1.09%

--- CASHFLOW ---
Entrate (esclusi dividendi): 34.250 €
Dividendi e cedole: 0 €
Uscite: -29.610 €
Flusso netto: 4640 €
Numero transazioni: 397 (di cui 384 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 34.250 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 24.030 € (70%)
Desideri: 5580 € (16%)
Risparmi: 4640 € (14%): 0 € di spese classificate come risparmio + 4640 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -9360 € (12 transazioni, 31,6% delle uscite)
  › Rata: -9360 € (12 transazioni)
Alimentari: -6480 € (108 transazioni, 21,9% delle uscite)
  › Supermercato: -5640 € (84 transazioni)
  › Mercato: -840 € (24 transazioni)
Casa: -4950 € (36 transazioni, 16,7% delle uscite)
  › Bollette: -3930 € (24 transazioni)
  › Condominio: -1020 € (12 transazioni)
Ristoranti: -2880 € (60 transazioni, 9,7% delle uscite)
Trasporti: -2520 € (60 transazioni, 8,5% delle uscite)
  › Carburante: -1680 € (36 transazioni)
  › Abbonamento treno: -840 € (12 transazioni)
Shopping: -2040 € (36 transazioni, 6,9% delle uscite)
Salute: -720 € (24 transazioni, 2,4% delle uscite)
Abbonamenti: -660 € (48 transazioni, 2,2% delle uscite)
  › Streaming: -360 € (24 transazioni)
  › Palestra: -300 € (12 transazioni)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 31.800 € (12 transazioni)
Tredicesima: 2450 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2022-11-08 · Casa › Bollette – gas: -610 €
2022-12-07 · Casa › Bollette – gas: -580 €
2022-08-10 · Ristoranti: -160 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Anno 2022 (12 mesi).

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +4640 €
Mercato: −12.340 €
Mutuo rimborsato: +5300 €
Altre variazioni: +260 €
Crescita del patrimonio: −2140 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
−10,6% annualizzato. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Immobili: 86.300 € (44,4% del patrimonio)
Azioni: 62.600 € (32,2% del patrimonio)
Obbligazioni: 24.300 € (12,5% del patrimonio)
Liquidità: 16.920 € (8,7% del patrimonio)
Materie Prime: 4340 € (2,2% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 108.160 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 57,9% | target 60,0% | scarto −2,1 p.p. (−2296 €) | in linea
Obbligazioni: attuale 22,5% | target 25,0% | scarto −2,5 p.p. (−2740 €) | in linea
Materie Prime: attuale 4,0% | target 5,0% | scarto −1,0 p.p. (−1068 €) | in linea
Liquidità: attuale 15,6% | target 10,0% | scarto +5,6 p.p. (+6104 €) | fuori target
Fuori dal totale 86.300 € esclusi (1 asset): il patrimonio è 194.460 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +1600 € = mercato −8900 € + acquisti e vendite +10.500 €
Obbligazioni: variazione −2200 € = mercato −3700 € + acquisti e vendite +1500 €
Materie Prime: variazione +240 € = mercato +240 €
Liquidità: variazione −7080 € = mercato +20 € + altri movimenti −7100 €
Immobili: variazione +5300 € = mercato 0 € + altri movimenti +5300 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 12 acquisti per 108 quote, 10.500 € investiti (commissioni incluse)
- BTP 2033 (Obbligazioni › Governativi Italia): 1 acquisto per 1500 quote, 1500 € investiti (commissioni incluse)
Totale del periodo: 12.000 € investiti in 13 acquisti. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 260 € lordi in 2 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Anno 2021) ---
Patrimonio netto: −2140 € (−1,1%), da 196.600 € a 194.460 €
Entrate: +1650 € (+5,1%), da 32.600 € a 34.250 €
Uscite: +4510 € (+18,0%), da 25.100 € a 29.610 €
Risparmio netto: −2860 € (−38,1%), da +7500 € a +4640 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 9360 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 6480 € (vs periodo prec.: +518 € (+8,7%); vs anno prec.: +518 € (+8,7%))
- Casa: 4950 € (vs periodo prec.: +1850 € (+59,7%); vs anno prec.: +1850 € (+59,7%))
- Ristoranti: 2880 € (vs periodo prec.: +230 € (+8,7%); vs anno prec.: +230 € (+8,7%))
- Trasporti: 2520 € (vs periodo prec.: +202 € (+8,7%); vs anno prec.: +202 € (+8,7%))
- Shopping: 2040 € (vs periodo prec.: +163 € (+8,7%); vs anno prec.: +163 € (+8,7%))
- Salute: 720 € (vs periodo prec.: +58 € (+8,8%); vs anno prec.: +58 € (+8,8%))
- Abbonamenti: 660 € (vs periodo prec.: +53 € (+8,7%); vs anno prec.: +53 € (+8,7%))

--- HALL OF FAME ---
È l'unico anno in calo registrato.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

