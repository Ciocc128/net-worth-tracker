Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Giugno 2026.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Giugno 2026 ===

--- PATRIMONIO ---
Inizio periodo: 302.500 €
Fine periodo: 305.025 €
Variazione assoluta: 2525 €
Variazione %: +0.83%

--- CASHFLOW ---
Entrate (esclusi dividendi): 3440 €
Dividendi e cedole: 0 €
Uscite: -2345 €
Flusso netto: 1095 €
Numero transazioni: 34 (di cui 32 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 3440 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 1880 € (55%)
Desideri: 465 € (14%)
Risparmi: 1095 € (31%): 0 € di spese classificate come risparmio + 1095 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -780 € (1 transazione, 33,3% delle uscite)
  › Rata: -780 € (1 transazione)
Alimentari: -540 € (9 transazioni, 23,0% delle uscite)
  › Supermercato: -470 € (7 transazioni)
  › Mercato: -70 € (2 transazioni)
Casa: -290 € (3 transazioni, 12,4% delle uscite)
  › Bollette: -205 € (2 transazioni)
  › Condominio: -85 € (1 transazione)
Ristoranti: -240 € (5 transazioni, 10,2% delle uscite)
Trasporti: -210 € (5 transazioni, 9,0% delle uscite)
  › Carburante: -140 € (3 transazioni)
  › Abbonamento treno: -70 € (1 transazione)
Shopping: -170 € (3 transazioni, 7,2% delle uscite)
Salute: -60 € (2 transazioni, 2,6% delle uscite)
Abbonamenti: -55 € (4 transazioni, 2,3% delle uscite)
  › Streaming: -30 € (2 transazioni)
  › Palestra: -25 € (1 transazione)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 3200 € (1 transazione)
Rimborsi: 240 € (1 transazione)

--- SPESE SINGOLE PIU' GRANDI ---
2026-06-02 · Mutuo › Rata: -780 €
2026-06-15 · Alimentari › Supermercato: -125 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Giugno 2026 (1 mese).
• La liquidità in eccesso rispetto al target è stata investita in due tranche il 3 e il 17 giugno.

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +1095 €
Mercato: +1430 €
Crescita del patrimonio: +2525 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+0,8% nel mese. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 123.380 € (40,4% del patrimonio)
Immobili: 96.000 € (31,5% del patrimonio)
Obbligazioni: 43.850 € (14,4% del patrimonio)
Liquidità: 32.155 € (10,5% del patrimonio)
Materie Prime: 9640 € (3,2% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 209.025 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Azioni: attuale 59,0% | target 60,0% | scarto −1,0 p.p. (−2035 €) | in linea
Obbligazioni: attuale 21,0% | target 25,0% | scarto −4,0 p.p. (−8406 €) | in linea
Materie Prime: attuale 4,6% | target 5,0% | scarto −0,4 p.p. (−811 €) | in linea
Liquidità: attuale 15,4% | target 10,0% | scarto +5,4 p.p. (+11.253 €) | fuori target
Fuori dal totale 96.000 € esclusi (1 asset): il patrimonio è 305.025 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +11.380 € = mercato +1380 € + acquisti e vendite +10.000 €
Obbligazioni: variazione +4850 € = mercato −150 € + acquisti e vendite +5000 €
Materie Prime: variazione +140 € = mercato +140 €
Liquidità: variazione −13.845 € = mercato +60 € + altri movimenti −13.905 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- VWCE (Azioni › Globale): 2 acquisti per 79,3 quote, 10.000 € investiti (commissioni incluse)
- AGGH (Obbligazioni › Aggregate globale): 1 acquisto per 1035 quote, 5000 € investiti (commissioni incluse)
Totale del periodo: 15.000 € investiti in 3 acquisti. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 0 € lordi in 0 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Maggio 2026) ---
Patrimonio netto: +2525 € (+0,8%), da 302.500 € a 305.025 €
Entrate: +240 € (+7,5%), da 3200 € a 3440 €
Uscite: +63 € (+2,8%), da 2282 € a 2345 €
Risparmio netto: +177 € (+19,3%), da +918 € a +1095 €

--- CONFRONTO CON LO STESSO PERIODO DELL'ANNO PRECEDENTE (Giugno 2025) ---
Patrimonio netto: +54.025 € (+21,5%), da 251.000 € a 305.025 €
Entrate: +390 € (+12,8%), da 3050 € a 3440 €
Uscite: +110 € (+4,9%), da 2235 € a 2345 €
Risparmio netto: +280 € (+34,4%), da +815 € a +1095 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 780 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 540 € (vs periodo prec.: +22 € (+4,2%); vs anno prec.: +38 € (+7,6%))
- Casa: 290 € (vs periodo prec.: +12 € (+4,3%); vs anno prec.: +20 € (+7,4%))
- Ristoranti: 240 € (vs periodo prec.: +10 € (+4,3%); vs anno prec.: +17 € (+7,6%))
- Trasporti: 210 € (vs periodo prec.: +8 € (+4,0%); vs anno prec.: +15 € (+7,7%))
- Shopping: 170 € (vs periodo prec.: +7 € (+4,3%); vs anno prec.: +12 € (+7,6%))
- Salute: 60 € (vs periodo prec.: +2 € (+3,4%); vs anno prec.: +4 € (+7,1%))
- Abbonamenti: 55 € (vs periodo prec.: +2 € (+3,8%); vs anno prec.: +4 € (+7,8%))

--- HALL OF FAME ---
È il 18° mese per crescita tra i 31 mesi in crescita registrati.
In altre parole: a metà classifica tra le crescite.
È un piazzamento in classifica tra tutti i periodi registrati, non una serie di periodi consecutivi.

--- CONTESTO MACRO (newsletter TheBull, giugno 2026) ---
Per ogni mese: i fatti per area, le tesi dell'autore e i rendimenti degli indici a fine mese.

## Macro di giugno 2026

### Fatti

#### Banche centrali

- La Fed mantiene i tassi invariati e rinvia ogni taglio alle prossime riunioni. — _Stati Uniti_ (2026-W24)

#### Inflazione

- L'inflazione core statunitense resta al 3,0%. — _Stati Uniti_ (2026-W26)

#### Crescita

- Il PIL italiano cresce dello 0,1% trimestre su trimestre. — _Italia_ (2026-W25)

#### Azionario

- L'Euro Stoxx 50 chiude il mese quasi invariato dopo oscillazioni ampie. — _Europa_ (2026-W25)

#### Debito pubblico

- Un'agenzia di rating conferma il giudizio sull'Italia con outlook stabile. — _Italia_ (2026-W24)

#### Materie prime

- Il petrolio Brent oscilla tra 65 e 70 dollari al barile. — _Globale_ (2026-W26)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore considera probabile una lunga fase laterale dei tassi. (2026-W26)
- **Azionario** — Secondo l'autore la diversificazione in oro ha fatto il suo lavoro negli ultimi due anni. (2026-W26)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +0.40% | +9.80% |
| FTSE MIB | +0.90% | +12.10% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

