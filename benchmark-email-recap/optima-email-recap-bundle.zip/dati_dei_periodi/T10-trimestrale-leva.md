Rispondi in modo equilibrato: chiaro, concreto e leggibile.
--- COSA SAI GIÀ SULL'INVESTITORE (memoria persistente) ---
Obiettivi finanziari:
- Vuole raggiungere l'indipendenza finanziaria (FIRE) intorno ai 50 anni; oggi ne ha 36.
Preferenze:
- Investe con un PAC mensile su ETF a basso costo e non fa market timing.
Profilo di rischio:
- Tollera bene la volatilità azionaria, è diffidente verso la leva.
Fatti utili:
- Vive in coppia con Giulia; hanno una casa con mutuo a tasso fisso fino al 2045.
Usa questi fatti per personalizzare la risposta quando sono pertinenti.

Stai redigendo il commento di riepilogo per: Q2 2026.
Di seguito i dati del periodo, estratti in modo affidabile dal sistema. Le variazioni sono già calcolate: non ricalcolarle e non inventare numeri.

=== DATI FINANZIARI: Q2 2026 ===

--- PATRIMONIO ---
Inizio periodo: 283.500 €
Fine periodo: 291.315 €
Variazione assoluta: 7815 €
Variazione %: +2.76%

--- CASHFLOW ---
Entrate (esclusi dividendi): 9600 €
Dividendi e cedole: 0 €
Uscite: -7035 €
Flusso netto: 2565 €
Numero transazioni: 99 (di cui 96 di spesa; i trasferimenti fra conti sono esclusi)

--- 50/30/20 SULLE ENTRATE (come il Flusso di Analisi) ---
Base: le entrate del periodo, 9600 €. La regola indica 50% Necessità, 30% Desideri, 20% Risparmi, sulle entrate.
Bisogni: 5640 € (59%)
Desideri: 1395 € (15%)
Risparmi: 2565 € (26%): 0 € di spese classificate come risparmio + 2565 € di avanzo (entrate meno uscite)

--- SPESE PER CATEGORIA E SOTTOCATEGORIA (elenco completo del periodo) ---
Mutuo: -2340 € (3 transazioni, 33,3% delle uscite)
  › Rata: -2340 € (3 transazioni)
Alimentari: -1620 € (27 transazioni, 23,0% delle uscite)
  › Supermercato: -1410 € (21 transazioni)
  › Mercato: -210 € (6 transazioni)
Casa: -870 € (9 transazioni, 12,4% delle uscite)
  › Bollette: -615 € (6 transazioni)
  › Condominio: -255 € (3 transazioni)
Ristoranti: -720 € (15 transazioni, 10,2% delle uscite)
Trasporti: -630 € (15 transazioni, 9,0% delle uscite)
  › Carburante: -420 € (9 transazioni)
  › Abbonamento treno: -210 € (3 transazioni)
Shopping: -510 € (9 transazioni, 7,2% delle uscite)
Salute: -180 € (6 transazioni, 2,6% delle uscite)
Abbonamenti: -165 € (12 transazioni, 2,3% delle uscite)
  › Streaming: -90 € (6 transazioni)
  › Palestra: -75 € (3 transazioni)

--- ENTRATE PER CATEGORIA (esclusi i dividendi, riportati sopra) ---
Stipendio: 9600 € (3 transazioni)

--- SPESE SINGOLE PIU' GRANDI ---
2026-04-02 · Mutuo › Rata: -780 €
2026-05-02 · Mutuo › Rata: -780 €
2026-06-02 · Mutuo › Rata: -780 €

--- OBIETTIVI DI INVESTIMENTO (Goal-Based Investing) ---
Goal-Based Investing non attivo: l'utente non usa questa funzionalità, quindi non ha obiettivi di investimento configurati. Non è un dato mancante.

--- CATEGORIE DI SPESA CONFIGURATE ---
Mutuo [debt] (sottocategorie: Rata)
Casa [fixed] (sottocategorie: Bollette, Condominio)
Alimentari [variable] (sottocategorie: Supermercato, Mercato)
Trasporti [variable] (sottocategorie: Carburante, Abbonamento treno)
Ristoranti [variable]
Shopping [variable]
Abbonamenti [fixed] (sottocategorie: Streaming, Palestra)
Salute [variable]

--- NOTE QUALITÀ DATI ---
• Finestra di analisi: Q2 2026 (3 mesi).

--- DA COSA VIENE LA VARIAZIONE DEL PATRIMONIO (calcolato, come il Driver dello Storico) ---
Risparmio: +2565 €
Mercato: +5250 €
Crescita del patrimonio: +7815 €
Il mercato è MISURATO strumento per strumento (variazione di prezzo delle quote detenute e delle operazioni del periodo, dal prezzo di carico al valore di fine periodo): non è un residuo. «Risparmio» sono entrate meno uscite registrate nel cashflow; «versamenti al fondo pensione» sono TFR e contributi registrati in Previdenza, che non passano dal cashflow; «altre variazioni» sono saldi inseriti a mano in giorni diversi dai movimenti, rettifiche, la differenza tra tassa stimata e trattenuta, e la crescita di un fondo pensione prima del mese da cui se ne misura il rendimento.
Le righe sono già calcolate e sommano alla crescita: usale così come sono, non ricalcolarle.

--- RENDIMENTO DEL PERIODO (TWR, come la pagina Rendimenti) ---
+4,6% nei 3 mesi. Base: portafoglio gestito, al netto dei fondi pensione e degli asset esclusi dall'allocazione.
Il TWR neutralizza versamenti e prelievi: misura quanto ha reso il capitale, non quanto è cresciuto il patrimonio.

--- COMPOSIZIONE DEL PATRIMONIO A FINE PERIODO (patrimonio intero, tutte le classi) ---
Azioni: 126.200 € (43,3% del patrimonio)
Immobili: 96.000 € (33,0% del patrimonio)
Obbligazioni: 38.760 € (13,3% del patrimonio)
Liquidità: 20.675 € (7,1% del patrimonio)
Materie Prime: 9680 € (3,3% del patrimonio)
Queste percentuali NON si confrontano con i target: i target valgono sul portafoglio allocato, nel blocco successivo.

--- ALLOCAZIONE vs TARGET (come la pagina Allocazione) ---
Base: il portafoglio allocato, 195.315 € a fine periodo (asset negoziabili e non negoziabili; gli esclusi, come la casa, sono fuori). Valori di fine periodo con i ruoli di oggi.
Origine dei target: Impostazioni → Allocazione, già riespressi sulla base (target effettivi). Una classe è fuori target secondo la regola 5/25: scarto oltre 5 punti o oltre il 25% del suo target.
Leva: 1,12×; le percentuali sono esposizioni nozionali sul capitale investito e possono sommare più di 100.
Azioni: attuale 64,6% | target 60,0% | scarto +4,6 p.p. (+9011 €) | in linea
  › Globale: 82,0% della classe (103.484 €) | target 90,0% della classe | scarto −8,0 p.p.
  › USA: 18,0% della classe (22.716 €) | target 10,0% della classe | scarto +8,0 p.p.
Obbligazioni: attuale 19,8% | target 25,0% | scarto −5,2 p.p. (−10.069 €) | fuori target
Materie Prime: attuale 5,0% | target 5,0% | scarto −0,0 p.p. (−86 €) | in linea
Liquidità: attuale 10,6% | target 10,0% | scarto +0,6 p.p. (+1143 €) | in linea
Fuori dal totale 96.000 € esclusi (1 asset): il patrimonio è 291.315 €.
I compositi sono divisi tra le classi secondo la loro composizione.

--- ANDAMENTO PER CLASSE (mercato separato da acquisti, vendite e versamenti) ---
Azioni: variazione +14.200 € = mercato +5200 € + acquisti e vendite +9000 €
Obbligazioni: variazione −240 € = mercato −240 €
Materie Prime: variazione +180 € = mercato +180 €
Liquidità: variazione −6325 € = mercato +110 € + altri movimenti −6435 €
«Acquisti e vendite» è denaro spostato dall'utente, non rendimento; «altri movimenti» sono depositi e prelievi sui conti, rate di mutuo, rettifiche. I fondi pensione sono la riga Previdenza: prima del mese da cui Previdenza misura il rendimento del fondo, tutta la sua crescita è «altri movimenti», perché non si separa dai versamenti.

--- OPERAZIONI DEL PERIODO (registro operazioni, per strumento; i primi 15 per importo) ---
- SPXL2 (Azioni › USA, leva 2×): 2 acquisti per 41 quote, 6000 € investiti (commissioni incluse)
- VWCE (Azioni › Globale): 3 acquisti per 24,1 quote, 3000 € investiti (commissioni incluse)
Totale del periodo: 9000 € investiti in 5 acquisti. Per classe, gli stessi importi sono le righe «acquisti e vendite» di ANDAMENTO PER CLASSE.
La classe tra parentesi è quella dello strumento (per un composito, le sue gambe): non dedurla dal nome o dal ticker. Gli acquisti pagati dai conti spiegano il calo della liquidità: non sono spese, non sono rendimento e non riducono il risparmio né il patrimonio.

--- DIVIDENDI DEL PERIODO (registro dividendi) ---
Incassati: 0 € lordi in 0 pagamenti.

--- CONFRONTO COL PERIODO PRECEDENTE (Q1 2026) ---
Patrimonio netto: +7815 € (+2,8%), da 283.500 € a 291.315 €
Entrate: +0 € (+0,0%), da 9600 € a 9600 €
Uscite: −445 € (−5,9%), da 7480 € a 7035 €
Risparmio netto: +445 € (+21,0%), da +2120 € a +2565 €

--- CONFRONTO CON LO STESSO PERIODO DELL'ANNO PRECEDENTE (Q2 2025) ---
Patrimonio netto: +45.315 € (+18,4%), da 246.000 € a 291.315 €
Entrate: +450 € (+4,9%), da 9150 € a 9600 €
Uscite: −15 € (−0,2%), da 7050 € a 7035 €
Risparmio netto: +465 € (+22,1%), da +2100 € a +2565 €

--- VARIAZIONE SPESE PER CATEGORIA (le prime 12 categorie per spesa del periodo) ---
- Mutuo: 2340 € (vs periodo prec.: +0 € (+0,0%); vs anno prec.: +0 € (+0,0%))
- Alimentari: 1620 € (vs periodo prec.: +65 € (+4,2%); vs anno prec.: +113 € (+7,5%))
- Casa: 870 € (vs periodo prec.: +35 € (+4,2%); vs anno prec.: +61 € (+7,5%))
- Ristoranti: 720 € (vs periodo prec.: +29 € (+4,2%); vs anno prec.: +50 € (+7,5%))
- Trasporti: 630 € (vs periodo prec.: +25 € (+4,1%); vs anno prec.: +44 € (+7,5%))
- Shopping: 510 € (vs periodo prec.: +20 € (+4,1%); vs anno prec.: +36 € (+7,6%))
- Salute: 180 € (vs periodo prec.: +7 € (+4,0%); vs anno prec.: +13 € (+7,8%))
- Abbonamenti: 165 € (vs periodo prec.: +7 € (+4,4%); vs anno prec.: +12 € (+7,8%))

--- CONTESTO MACRO (newsletter TheBull, aprile 2026, maggio 2026, giugno 2026) ---
Per ogni mese: i fatti per area, le tesi dell'autore e i rendimenti degli indici a fine mese.

## Macro di aprile 2026

### Fatti

#### Banche centrali

- La Fed mantiene i tassi invariati e rinvia ogni taglio alle prossime riunioni. — _Stati Uniti_ (2026-W16)

#### Inflazione

- L'inflazione core statunitense resta al 3,0%. — _Stati Uniti_ (2026-W18)

#### Crescita

- Il PIL italiano cresce dello 0,1% trimestre su trimestre. — _Italia_ (2026-W17)

#### Azionario

- L'Euro Stoxx 50 chiude il mese quasi invariato dopo oscillazioni ampie. — _Europa_ (2026-W17)

#### Debito pubblico

- Un'agenzia di rating conferma il giudizio sull'Italia con outlook stabile. — _Italia_ (2026-W16)

#### Materie prime

- Il petrolio Brent oscilla tra 65 e 70 dollari al barile. — _Globale_ (2026-W18)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — L'autore considera probabile una lunga fase laterale dei tassi. (2026-W18)
- **Azionario** — Secondo l'autore la diversificazione in oro ha fatto il suo lavoro negli ultimi due anni. (2026-W18)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +0.40% | +9.80% |
| FTSE MIB | +0.90% | +12.10% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di maggio 2026

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2026-W20)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2026-W22)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2026-W20)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2026-W21)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2026-W21)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2026-W20)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2026-W22)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2026-W22)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2026-W22)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

## Macro di giugno 2026

### Fatti

#### Banche centrali

- La BCE lascia il tasso sui depositi al 2,00% e segnala che il ciclo di tagli è concluso. — _Eurozona_ (2026-W24)

#### Inflazione

- L'inflazione dell'area euro scende al 2,1% annuo, in linea con l'obiettivo. — _Eurozona_ (2026-W26)

#### Crescita

- Il PMI composito dell'area euro sale a 52,4, il livello più alto da due anni. — _Eurozona_ (2026-W24)

#### Azionario

- L'S&P 500 chiude il mese su un nuovo massimo storico, guidato dai titoli tecnologici. — _Stati Uniti_ (2026-W25)

#### Obbligazionario

- Lo spread BTP-Bund si restringe a 85 punti base. — _Italia_ (2026-W25)

#### Cambio

- L'euro si rafforza a 1,17 sul dollaro. — _Globale_ (2026-W24)

#### Materie prime

- L'oro si stabilizza dopo il rialzo dei mesi precedenti. — _Globale_ (2026-W26)

### Tesi dell'autore

_Opinioni di TheBull, non fatti._

- **Azionario** — Secondo l'autore le valutazioni azionarie USA sono tirate e il rendimento atteso dei prossimi anni è più basso della media storica. (2026-W26)
- **Azionario** — L'autore ritiene che i BTP restino interessanti per chi cerca cedole, ma senza allungare troppo la durata. (2026-W26)

### Rendimenti degli indici (ultima settimana del mese)

| Indice | 1 mese | 1 anno |
| --- | ---: | ---: |
| MSCI All Country World | +3.12% | +18.40% |
| FTSE MIB | +2.40% | +21.30% |
| Bloomberg Euro Aggregate | +0.30% | +3.40% |
| Oro | +0.60% | +21.00% |

_Variazioni in % in Euro._

