# Task

Un task per file di dati. `system_prompt` e `prompt` sono i file indicati, **testuali e interi**. Le «trappole» sono fatti verificabili nel blocco dati: una risposta che li sbaglia o li contraddice è debole. Non sono risposte da consegnare al modello.

## T01 · Maggio 2026 · Mensile: mese buono, PAC regolare, mercato in rialzo

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T01-mensile-buono.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Il risparmio del mese (entrate meno uscite) e l'effetto mercato sono attribuiti con le cifre del blocco DA COSA VIENE LA VARIAZIONE, senza ricalcolarle.
  - Il PAC da 1.000 € su VWCE è descritto come investimento (denaro spostato), non come spesa né come rendimento.
  - La Hall of Fame (5° su 31) è letta come piazzamento 'tra le crescite più forti', non come serie di mesi consecutivi.

## T02 · Marzo 2026 · Mensile: mese negativo, calo di mercato, PAC mantenuto

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T02-mensile-negativo.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Il calo del patrimonio è attribuito al mercato azionario (circa −7.650 € sulle Azioni) e non al risparmio, che resta positivo.
  - Il contesto macro (dazi, calo dell'MSCI World) è usato per spiegare il mercato del portafoglio senza presentare cifre macro come cifre del portafoglio.
  - Collega il PAC mantenuto nel mese negativo al principio dichiarato 'il PAC non si sospende nei mesi negativi', nominandolo.
  - Il 2° posto tra i cali è letto come 'tra i cali più marcati' (2° su 9), senza drammatizzare né inventare serie.

## T03 · Febbraio 2026 · Mensile: spese anomale e budget superati

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T03-mensile-budget-sforati.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Nomina i due budget superati (Shopping 1.240 € su 250 €, Ristoranti 610 € su 300 €) e l'avviso all'80% su Alimentari con le cifre esatte.
  - Lega lo sforamento dello Shopping alla singola spesa del notebook (720 €) invece di parlare di un generico aumento.
  - Dice che il mese chiude con uscite (3.935 €) oltre le entrate (3.200 €), deficit coperto dal patrimonio, e lo confronta con l'obiettivo di risparmio del 30% dei principi senza inventare percentuali.

## T04 · Giugno 2026 · Mensile: grandi acquisti dalla liquidità (non sono spese)

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T04-mensile-acquisti-grandi.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Gli acquisti da 15.000 € (VWCE 10.000 €, AGGH 5.000 €) sono descritti come liquidità spostata in investimenti: NON come spese, NON come rendimento, NON come calo del risparmio o del patrimonio.
  - Il forte calo della liquidità è spiegato dagli acquisti, citando il totale del blocco OPERAZIONI.
  - AGGH è chiamato obbligazionario (classe dal blocco), non dedotto dal ticker in modo diverso.
  - Collega l'investimento della liquidità in eccesso al target del 10% di liquidità o al principio sul fondo di emergenza, senza inventare il valore del fondo.

## T05 · Luglio 2026 · Mensile: vendita con plusvalenza e tasse trattenute

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T05-mensile-vendita-tassata.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - La tassa di 1.310 € trattenuta sulla vendita è indicata come costo della vendita (riga 'tasse sulle vendite'), non come perdita di mercato.
  - Cita i 18.000 € incassati e la plusvalenza realizzata senza inventare il prezzo medio di carico o il numero di quote residue.
  - La quattordicesima (2.900 €) è riconosciuta come entrata straordinaria che gonfia il risparmio del mese.
  - Valuta la vendita alla luce del principio 'si ribilancia con i nuovi versamenti, non con le vendite' in modo esplicito (la nota dice che è per un obiettivo, non per ribilanciare).

## T06 · Settembre 2026 · Mensile: Viaggi scesi a zero e spesa straordinaria per la casa

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T06-mensile-categoria-a-zero.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Nota che i Viaggi sono scesi a zero (1.150 € nel mese precedente, nessuna spesa ora) leggendolo dalla riga 'Scese a zero'.
  - Attribuisce l'aumento della categoria Casa alla sostituzione della caldaia (2.400 €, spesa una tantum), non a un nuovo livello stabile.
  - Collega la spesa straordinaria al principio 'le spese straordinarie si pianificano con un obiettivo dedicato' (osservazione, non rimprovero).

## T07 · Gennaio 2026 · Mensile: snapshot di inizio periodo mancante, niente macro

- system_prompt: `prompt_di_sistema/sistema_mensile_solo_principi.md`
- prompt: `dati_dei_periodi/T07-mensile-dati-mancanti.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Dice chiaramente che la variazione del patrimonio del mese e l'allocazione non sono calcolabili (snapshot di inizio mancante) e NON stima un effetto mercato o un rendimento.
  - Non inventa un rendimento del mese, né scostamenti dai target, né un contesto macro (nessun blocco macro presente).
  - Spiega il calo delle entrate rispetto a dicembre (6.050 € → 3.200 €) come assenza della tredicesima solo come ipotesi dichiarata.

## T08 · Agosto 2026 · Mensile: uscite oltre le entrate (vacanze) e divisione delle spese di coppia

- system_prompt: `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T08-mensile-deficit-divisione.md`
- limite: 500 parole; budget di uscita in produzione 7800 token
- Fatti da rispettare (evidenza nel file di dati):
  - Dice che le uscite (5.895 €) hanno superato le entrate (5.550 €) e che il deficit di 345 € è coperto dal patrimonio, con le cifre del blocco 50/30/20, senza inventarne altre.
  - Lega le uscite alte alle vacanze (Viaggi 2.950 €, alloggio in Sardegna) e nota che è un evento stagionale (agosto 2025 simile), come ipotesi dichiarata.
  - Riporta la divisione di coppia con le quote e il 'resta' di Marco e Giulia esattamente come nel blocco DIVISIONE.

## T09 · Q1 2026 · Trimestrale: trimestre volatile, chiusura leggermente negativa

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T09-trimestrale-volatile.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Racconta il trimestre come sequenza (due mesi tranquilli o positivi poi marzo negativo) solo sulla base del contesto macro mensile, senza inventare il risultato del singolo mese del portafoglio.
  - Distingue il TWR (−1,2% nei 3 mesi) dalla variazione del patrimonio, che include risparmio e PAC.
  - Nota che oro e obbligazioni hanno attenuato il calo azionario (righe di ANDAMENTO PER CLASSE), collegandolo alla diversificazione.

## T10 · Q2 2026 · Trimestrale: introduzione di un ETF a leva 2×

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T10-trimestrale-leva.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Identifica SPXL2 come Azioni USA con leva 2× (dal blocco) e riporta la leva del portafoglio 1,12× senza confonderla con quella dello strumento.
  - Confronta la leva introdotta con il principio 'mai oltre 1,2× sul portafoglio' e con la memoria 'diffidente verso la leva': nota la tensione apertamente, senza moralismi.
  - Non presenta i 6.000 € investiti nell'ETF a leva come guadagno; il rendimento si legge dal TWR (+4,6%).

## T11 · Q3 2026 · Trimestrale: cambio di lavoro, TFR liquidato e nascita di un figlio

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T11-trimestrale-cambio-di-vita.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Riconosce la nuova categoria Bambino come cambio di vita (nascita), dichiarandolo come ipotesi coerente con i dati, non come errore di registrazione.
  - Spiega che le entrate del trimestre sono gonfiate dalla liquidazione del TFR (6.800 €, una tantum) mentre lo stipendio ha solo due accrediti: legge il possibile cambio di lavoro come ipotesi.
  - Distingue i dividendi/cedole del registro (1.250 € in 3 pagamenti) dalle entrate del cashflow, senza sommarli.
  - Il BTP da 4.000 € è un investimento obbligazionario, non una spesa.

## T12 · Q4 2025 · Trimestrale: mercato non misurato strumento per strumento

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T12-trimestrale-mercato-non-misurato.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Presenta l'effetto mercato come STIMA residua (non misurato strumento per strumento), non come rendimento, e non attribuisce variazioni di mercato a singole classi.
  - Non inventa un TWR (assente) né un rendimento per classe.
  - Riconosce tredicesima e regali di Natale come stagionalità di fine anno, confrontandoli con il Q4 2024.

## T13 · Q3 2025 · Trimestrale: rally azionario, Azioni fuori target secondo la regola 5/25

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T13-trimestrale-fuori-target.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Segnala le classi fuori target (Azioni +8,5 p.p., Obbligazioni −6,9 p.p.) con gli scarti del blocco ALLOCAZIONE, non con le percentuali della composizione sul patrimonio intero.
  - Applica i principi: ribilanciare con i nuovi versamenti (indirizzare il PAC su obbligazioni/liquidità), vendere solo se fuori banda per più di un trimestre; non raccomanda di vendere subito.
  - Cita le tesi dell'autore (valutazioni USA tirate) come opinioni attribuite, non come fatti.

## T14 · 1° semestre 2026 · Semestrale: semestre positivo con mutuo e fondo pensione

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T14-semestrale-mutuo-previdenza.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Spiega i 'motori' della crescita con le righe del Driver: risparmio, mercato, mutuo rimborsato (2.950 €) e versamenti al fondo pensione (2.900 €), senza fonderli in un unico 'guadagno'.
  - Spiega che i versamenti al fondo pensione non passano dal cashflow e non sono rendimento.
  - Distingue la rata del mutuo come spesa (cashflow) dalla quota capitale rimborsata che aumenta il patrimonio netto.

## T15 · 2° semestre 2025 · Semestrale: semestre negativo, vendita di oro in guadagno per comprare obbligazioni

- system_prompt: `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T15-semestrale-negativo-vendite.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Riconosce che per settembre 2025 manca la pagina macro e non ne inventa il contesto.
  - Descrive la vendita di SGLD (oro, 6.500 € incassati, 410 € di tasse) e l'acquisto di AGGH (obbligazioni) come ribilanciamento, valutandolo rispetto al principio 'vendere solo se fuori banda per più di un trimestre'.
  - Il calo è attribuito alle Azioni (mercato −9.400 €), con l'oro in guadagno; i totali di acquisti e vendite sono quelli del blocco.

## T16 · 1° semestre 2025 · Semestrale: nessun contesto macro né principi (Wiki assente)

- system_prompt: `prompt_di_sistema/sistema_semestrale_senza_wiki.md`
- prompt: `dati_dei_periodi/T16-semestrale-senza-wiki.md`
- limite: 650 parole; budget di uscita in produzione 12340 token
- Fatti da rispettare (evidenza nel file di dati):
  - Non cita eventi macro, banche centrali o notizie di mercato né principi dell'investitore: nessun blocco li fornisce.
  - Non promette né nomina sezioni o dati assenti (macro, principi).
  - Il rendimento (TWR +2,4% nei 6 mesi) è distinto dalla crescita del patrimonio dovuta al risparmio e al PAC.

## T17 · Anno 2025 · Annuale: anno record, obiettivo FIRE in linea

- system_prompt: `prompt_di_sistema/sistema_annuale_con_macro_e_principi.md`
- prompt: `dati_dei_periodi/T17-annuale-record.md`
- limite: 800 parole; budget di uscita in produzione 13880 token
- Fatti da rispettare (evidenza nel file di dati):
  - Riconosce il 1° posto su 5 nella Hall of Fame degli anni come anno migliore registrato, con la crescita del Driver.
  - Riporta gli obiettivi con i loro verdetti: Indipendenza finanziaria in linea, Auto nuova in ritardo (servono 470 €/mese contro 400 €), dichiarando che le proiezioni poggiano sul rendimento ipotizzato.
  - Usa il bonus (4.200 €) e la tredicesima come entrate straordinarie nella lettura del tasso di risparmio, senza calcolare un nuovo tasso non fornito.
  - Sintetizza l'anno macro (marzo-aprile negativi, poi recupero) senza attribuire cifre macro al portafoglio.

## T18 · Anno 2022 · Annuale: anno di calo di azioni e obbligazioni insieme, solo principi

- system_prompt: `prompt_di_sistema/sistema_annuale_solo_principi.md`
- prompt: `dati_dei_periodi/T18-annuale-calo-2022.md`
- limite: 800 parole; budget di uscita in produzione 13880 token
- Fatti da rispettare (evidenza nel file di dati):
  - Nessun blocco macro: non presenta come dati forniti eventi dell'anno (inflazione, tassi, guerra) che non sono nel prompt, o se li evoca li dichiara come conoscenza generale e non come dati del periodo.
  - Nota che azioni e obbligazioni sono scese insieme (righe di ANDAMENTO PER CLASSE), con la diversificazione che non ha protetto, e che il patrimonio è comunque cresciuto grazie a risparmio, PAC e mutuo.
  - Attribuisce l'aumento della categoria Casa alle bollette (3.930 €), citando le singole bollette del gas.
  - La Hall of Fame (1° su 1 tra i cali) non è presentata come record significativo: c'è un solo anno di calo registrato.

## T19 · Anno 2023 · Annuale: molte operazioni (oltre 15 strumenti), compositi e obiettivi in ritardo

- system_prompt: `prompt_di_sistema/sistema_annuale_solo_principi.md`
- prompt: `dati_dei_periodi/T19-annuale-tanti-strumenti.md`
- limite: 800 parole; budget di uscita in produzione 13880 token
- Fatti da rispettare (evidenza nel file di dati):
  - Usa i totali del blocco OPERAZIONI (investito e numero di acquisti) e la riga 'oltre i primi 15 restano N strumenti' invece di sommare a mano.
  - VNGA60 è descritto come composito 60% azioni / 40% obbligazioni, non come solo azionario.
  - Segnala l'obiettivo Indipendenza finanziaria in ritardo (1.150 €/mese richiesti contro 600 €) e lo collega alla frammentazione del portafoglio come osservazione dichiarata.
  - Il 3° posto su 3 tra le crescite è letto come 'tra le crescite più deboli', non come un buon piazzamento.

## T20 · Anno 2024 · Annuale: crypto ed oro in forte rialzo, classe crypto fuori dai target

- system_prompt: `prompt_di_sistema/sistema_annuale_solo_principi.md`
- prompt: `dati_dei_periodi/T20-annuale-crypto-oro.md`
- limite: 800 parole; budget di uscita in produzione 13880 token
- Fatti da rispettare (evidenza nel file di dati):
  - Nota che le Criptovalute hanno target 0% ma pesano il 4,8% del portafoglio (+3.700 € di mercato), quindi sono fuori dal piano di allocazione dichiarato nei principi.
  - Non calcola nulla da sé: nessun rendimento percentuale della crypto inventato (il blocco dà solo euro).
  - Riconosce il 2° posto su 4 tra le crescite annuali e collega l'anno buono soprattutto alle azioni.

## Criteri comuni a tutti i task

- Verità delle cifre: Ogni cifra in euro o percentuale del testo compare nel blocco dati (dati.md), a meno dell'arrotondamento; il modello non somma, non sottrae e non calcola percentuali o medie proprie.
- Nessun errore grave: Nessuna affermazione sbagliata sui dati che orienterebbe male una decisione: acquisti o vendite letti come spese o rendimento, classe di uno strumento diversa da quella tra parentesi, Hall of Fame letta come serie di periodi consecutivi, cifre macro presentate come del portafoglio, dati N/D o assenti stimati.
- Forma e lunghezza: Prosa in italiano, in seconda persona, divisa da 3-5 titoletti propri (##) che dicono il senso del paragrafo; nessun elenco puntato o numerato, nessuna tabella; entro il limite di parole del periodo; nessuna premessa, disclaimer o chiusura di cortesia.
- Racconto e collegamenti: Un filo unico che va dalla persona (entrate, spese) al portafoglio e, se c'è il contesto macro, al mondo; contiene almeno un collegamento tra due dati che nessun numero da solo mostra; le ipotesi sono dichiarate una volta e poggiano su una transazione o una categoria precisa.
- Utilità: Le mosse proposte sono al massimo due, concrete, giustificate dai dati e dai principi forniti; se il piano sta già lavorando lo dice e si ferma. Un lettore saprebbe cosa fare (o di non dover fare nulla) dopo averla letta.
