# Net Worth Tracker: un'app che manda a un investitore italiano email di riepilogo del suo patrimonio, con un commento scritto da un LLM

## The task we want measured
A fine mese, trimestre, semestre e anno l'app manda un'email di riepilogo. In cima all'email c'è un commento in prosa italiana scritto da un LLM. Per ogni periodo l'app costruisce una richiesta fissa:
- un **prompt di sistema** con ruolo, regole di verità dei dati e contratto narrativo; cambia per tipo di periodo e per la presenza della Wiki (macro e principi);
- un **messaggio utente** con il blocco dati del periodo, da 4.000 a 10.000 token: patrimonio, Driver della variazione, TWR, composizione, allocazione contro target, andamento per classe, operazioni, dividendi, confronti, Hall of Fame, budget, divisione delle spese, poi il contesto macro mensile da una newsletter (TheBull) e la memoria dell'investitore.

Il modello deve restituire solo il commento. È difficile perché deve:
1. usare solo cifre presenti nel blocco, senza sommare né calcolare;
2. non cadere nelle trappole dei dati: gli acquisti non sono spese, una tassa trattenuta non è una perdita di mercato, una categoria scesa a zero si nota, un dato mancante non si stima;
3. scrivere una lettera coesa e non schematica, che colleghi la vita dell'investitore, il portafoglio e il mercato.

**Importante: questo benchmark deve misurare il compito VERO.** In un giro precedente l'agente ha riscritto i task come prompt brevi di circa 500 token, con un prompt di sistema di quattro righe. Lì tutti i modelli erano precisi e il test non distingueva più. Per questo ogni task deve usare **testualmente** i file allegati:
- `system_prompt` = il contenuto intero del file in `prompt_di_sistema/` indicato in `02_TASK_SEEDS.md`;
- `prompt` = il contenuto intero del file in `dati_dei_periodi/` dello stesso task;
- nessun riassunto, taglio o riformulazione: sono i prompt che l'app manda in produzione, generati dal suo codice.

## What's attached
- `prompt_di_sistema/` (6 file): i prompt di sistema reali dell'app, generati dal suo codice. Sono identici a quelli di produzione.
- `dati_dei_periodi/` (20 file): i messaggi utente reali, generati dal codice dell'app su 20 scenari **sintetici** (persona inventata, cifre inventate, newsletter e principi inventati). Il formato e la lunghezza sono quelli veri. I dati veri dell'utente non si possono caricare.

## What a good answer looks like
È il giudizio del proprietario dopo tre giri di valutazione fatti a mano:
- «I dati devono essere veri, ma le email non le voglio asciutte, asettiche e prudenti, né schematiche: coese, che ti prendono mentre le leggi, che fanno capire i collegamenti tra i numeri e quello che succede nel mondo reale, e che uniscono i dati tirando fuori insight che un numero da solo non mostra.»
- Ogni cifra in euro o in percentuale compare nel blocco dati. Le ipotesi sulla vita dell'investitore sono dichiarate una volta e poggiano su una transazione precisa.
- Prosa con 3-5 titoletti scritti dal modello, niente elenchi né tabelle, entro il limite di parole: 500 mensile, 650 trimestrale e semestrale, 800 annuale.
- Un principio dell'investitore, quando è usato, viene nominato. Una tesi della newsletter si riporta come opinione dell'autore.

## What a weak answer looks like
Errori visti davvero nei giri precedenti:
- acquisti di ETF letti come spese o come calo del risparmio;
- la classe di uno strumento dedotta dal ticker invece che letta dal blocco;
- la Hall of Fame letta come una serie («18 mesi di crescita di fila» per un «18° su 19»);
- somme e percentuali calcolate dal modello e sbagliate;
- cifre macro presentate come cifre del portafoglio;
- una categoria scesa a zero che nessuno nota;
- il 50/30/20 calcolato sulle uscite invece che sulle entrate;
- prosa che ripete i numeri senza interpretarli, oppure ogni frase piena di «probabilmente».

## How this work divides
Per periodo: 8 mensili, 5 trimestrali, 3 semestrali, 4 annuali. Per tipo di caso:
- periodi ordinari;
- cashflow eccezionale: budget sforati, spese una tantum, deficit;
- scelte di portafoglio: acquisti grandi, vendite tassate, leva, fuori target;
- dati difficili o mancanti: snapshot assente, mercato non misurato, nessuna Wiki, più di 15 strumenti.

## The shape of an answer
Un testo markdown in italiano: il commento dell'email e nient'altro.

## Scale
I 20 task di `02_TASK_SEEDS.md`, uno per file di dati, senza aggiungerne né toglierne. Va bene una ripetizione per task, se serve. Modelli da confrontare: GPT-6.1 Sol (high), DeepSeek V4.1 Flash (high), GLM-5.3-Flash.

## Over to you
Il voto è a tua scelta, con un vincolo di priorità: prima nessun errore sui dati (una cifra non presente nel blocco o un'affermazione sbagliata pesa più di tutto il resto), poi «ti prende» ed è coesa, poi i collegamenti, poi l'utilità delle eventuali mosse. I criteri specifici di ogni task sono in `02_TASK_SEEDS.md`. Show me the plan before you build it.
