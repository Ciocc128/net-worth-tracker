# Fonti

Tutti i file sono **generati** dal codice di produzione dell'app (`buildEmailAiPrompt`) su scenari sintetici: il formato, le regole e la lunghezza sono quelli reali; persona, cifre, newsletter e principi sono inventati.

## prompt_di_sistema/

- `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`: prompt di sistema mensile (limite 500 parole), con regole e digest dei principi e regole sul contesto macro. Generato.
- `prompt_di_sistema/sistema_mensile_solo_principi.md`: prompt di sistema mensile, con i principi ma senza contesto macro (nessuna pagina della newsletter per il mese). Generato.
- `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`: prompt di sistema trimestrale e semestrale (limite 650 parole), con macro e principi. Generato.
- `prompt_di_sistema/sistema_semestrale_senza_wiki.md`: prompt di sistema semestrale senza Wiki: né macro né principi. Generato.
- `prompt_di_sistema/sistema_annuale_con_macro_e_principi.md`: prompt di sistema annuale (limite 800 parole), con macro e principi. Generato.
- `prompt_di_sistema/sistema_annuale_solo_principi.md`: prompt di sistema annuale con i principi ma senza contesto macro. Generato.

## dati_dei_periodi/

- `dati_dei_periodi/T01-mensile-buono.md`: messaggio utente di «Maggio 2026», mensile: mese buono, pac regolare, mercato in rialzo. Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T01.
- `dati_dei_periodi/T02-mensile-negativo.md`: messaggio utente di «Marzo 2026», mensile: mese negativo, calo di mercato, pac mantenuto. Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T02.
- `dati_dei_periodi/T03-mensile-budget-sforati.md`: messaggio utente di «Febbraio 2026», mensile: spese anomale e budget superati. Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T03.
- `dati_dei_periodi/T04-mensile-acquisti-grandi.md`: messaggio utente di «Giugno 2026», mensile: grandi acquisti dalla liquidità (non sono spese). Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T04.
- `dati_dei_periodi/T05-mensile-vendita-tassata.md`: messaggio utente di «Luglio 2026», mensile: vendita con plusvalenza e tasse trattenute. Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T05.
- `dati_dei_periodi/T06-mensile-categoria-a-zero.md`: messaggio utente di «Settembre 2026», mensile: viaggi scesi a zero e spesa straordinaria per la casa. Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T06.
- `dati_dei_periodi/T07-mensile-dati-mancanti.md`: messaggio utente di «Gennaio 2026», mensile: snapshot di inizio periodo mancante, niente macro. Generato. Va con `prompt_di_sistema/sistema_mensile_solo_principi.md`. Vedi `02_TASK_SEEDS.md` § T07.
- `dati_dei_periodi/T08-mensile-deficit-divisione.md`: messaggio utente di «Agosto 2026», mensile: uscite oltre le entrate (vacanze) e divisione delle spese di coppia. Generato. Va con `prompt_di_sistema/sistema_mensile_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T08.
- `dati_dei_periodi/T09-trimestrale-volatile.md`: messaggio utente di «Q1 2026», trimestrale: trimestre volatile, chiusura leggermente negativa. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T09.
- `dati_dei_periodi/T10-trimestrale-leva.md`: messaggio utente di «Q2 2026», trimestrale: introduzione di un etf a leva 2×. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T10.
- `dati_dei_periodi/T11-trimestrale-cambio-di-vita.md`: messaggio utente di «Q3 2026», trimestrale: cambio di lavoro, tfr liquidato e nascita di un figlio. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T11.
- `dati_dei_periodi/T12-trimestrale-mercato-non-misurato.md`: messaggio utente di «Q4 2025», trimestrale: mercato non misurato strumento per strumento. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T12.
- `dati_dei_periodi/T13-trimestrale-fuori-target.md`: messaggio utente di «Q3 2025», trimestrale: rally azionario, azioni fuori target secondo la regola 5/25. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T13.
- `dati_dei_periodi/T14-semestrale-mutuo-previdenza.md`: messaggio utente di «1° semestre 2026», semestrale: semestre positivo con mutuo e fondo pensione. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T14.
- `dati_dei_periodi/T15-semestrale-negativo-vendite.md`: messaggio utente di «2° semestre 2025», semestrale: semestre negativo, vendita di oro in guadagno per comprare obbligazioni. Generato. Va con `prompt_di_sistema/sistema_trimestrale_e_semestrale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T15.
- `dati_dei_periodi/T16-semestrale-senza-wiki.md`: messaggio utente di «1° semestre 2025», semestrale: nessun contesto macro né principi (wiki assente). Generato. Va con `prompt_di_sistema/sistema_semestrale_senza_wiki.md`. Vedi `02_TASK_SEEDS.md` § T16.
- `dati_dei_periodi/T17-annuale-record.md`: messaggio utente di «Anno 2025», annuale: anno record, obiettivo fire in linea. Generato. Va con `prompt_di_sistema/sistema_annuale_con_macro_e_principi.md`. Vedi `02_TASK_SEEDS.md` § T17.
- `dati_dei_periodi/T18-annuale-calo-2022.md`: messaggio utente di «Anno 2022», annuale: anno di calo di azioni e obbligazioni insieme, solo principi. Generato. Va con `prompt_di_sistema/sistema_annuale_solo_principi.md`. Vedi `02_TASK_SEEDS.md` § T18.
- `dati_dei_periodi/T19-annuale-tanti-strumenti.md`: messaggio utente di «Anno 2023», annuale: molte operazioni (oltre 15 strumenti), compositi e obiettivi in ritardo. Generato. Va con `prompt_di_sistema/sistema_annuale_solo_principi.md`. Vedi `02_TASK_SEEDS.md` § T19.
- `dati_dei_periodi/T20-annuale-crypto-oro.md`: messaggio utente di «Anno 2024», annuale: crypto ed oro in forte rialzo, classe crypto fuori dai target. Generato. Va con `prompt_di_sistema/sistema_annuale_solo_principi.md`. Vedi `02_TASK_SEEDS.md` § T20.
